P�RCIULESCU VALENTINA - 323CD

	Convertirea unui nr din baza 10 in baza n 

- parcurg vectorul si procesez fiecare element astfel:
	-> verific daca baza in care trebuie sa convertesc nr se afla in intervalul [2, 16]
		-> daca e in afara intervalului, afisez mesajul 
			de eroare "Baza incorecta" si trec la urmatorul element
		-> daca e in interval incep convertirea
	-> impart numarul la baza pana cand devine 0 si retin resturile in stiva (push)
	-> afisez rezultatul folosindu-ma de stiva (pop) 
	  (pe stiva se afla numere in intervalul [0, 15])
	-> daca nr < 9 fac convertire adaugand 48 (codul ascii)
	-> daca nr > 9 fac convertire adaugand 87 (a,b,c,d,e,f)